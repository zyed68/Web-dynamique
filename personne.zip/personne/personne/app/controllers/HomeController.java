package controllers;

import play.mvc.*;

import models.*;

import javax.inject.Inject;
import play.i18n.MessagesApi;
import play.data.*;

import views.html.*;
import play.data.validation.Constraints.*;

import java.util.List;
/**
 * This controller contains an action to handle HTTP requests
 * to the application's home page.
 */
public class HomeController extends Controller {

    /**
     * An action that renders an HTML page with a welcome message.
     * The configuration in the <code>routes</code> file means that
     * this method will be called when the application receives a
     * <code>GET</code> request with a path of <code>/</code>.
     */    

    @Inject
    FormFactory formFactory;
    Form<Personne> personneForm;
    MessagesApi messagesApi;
    
    @Inject
    public HomeController(FormFactory formFactory, MessagesApi messagesApi){
        this.personneForm = formFactory.form(Personne.class);
        this.messagesApi = messagesApi;
    }
    
    public Result index() {
        return ok(views.html.index.render());
    }
    
    
    public Result ajoutPersonne(Http.Request request){
        return ok(views.html.ajoutPersonne.render(personneForm,request,messagesApi.preferred(request)));
    }
    
    public Result personneOk(Http.Request request){
        Form<Personne> lform = personneForm.bindFromRequest(request);
        if (lform.hasErrors()){
            return badRequest(ajoutPersonne.render(lform, request, messagesApi.preferred(request)));
        } else {
        Personne personne = lform.get();
            personne.save();
        return redirect(routes.HomeController.all());
        }
    
    }
 
    public Result all(){
        List<Personne> liste = Personne.find.all();
        return ok(all.render(liste));
    }
    
    public Result show(Long id){
        Personne personne = Personne.find.byId(id);
        return ok(show.render(personne));
    }
    
    public Result delete(Long id){
        Personne personne = Personne.find.byId(id);
        personne.delete();
        return redirect (routes.HomeController.all());
    }
    
    public Result update(Long id, Http.Request request){
         Personne personne = Personne.find.byId(id);
         personneForm = personneForm.fill(personne);
         return ok(update.render(personneForm, id, request, messagesApi.preferred(request)));
    }
    
     public Result updateOk(Long id, Http.Request request){
         Form<Personne> lform = personneForm.bindFromRequest(request);
        if (lform.hasErrors()){
            return badRequest(update.render(lform, id, request, messagesApi.preferred(request)));
        } else {
        Personne personne = lform.get();
            personne.setId(id);
            personne.update();
        return redirect(routes.HomeController.all());
        }
    } 
    
    
    
}
