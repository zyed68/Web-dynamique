package models;

import java.util.Date;

import io.ebean.*;
import javax.persistence.*;

import play.data.validation.Constraints.*;

@Entity
public class Personne extends Model{
  
    private static final long serialVersionUID = 1L; 
    
    @Id
    private long id;
    
    @Required
    @Pattern(value="^[A-Z][a-z0-9 ]{2,}", message="le nom doit commencer par une majusucule")
    private String nom;
    @Required
    @Min(value=3, message="le personne doit avoir au moins 3 ans")
    private int age;

    public Personne(){
        this.nom="Le seigneur des anneaux";
        this.age=10;
    }
    
    public String getnom(){
        return this.nom;
    }
    
    public void setnom(String nom){
        this.nom = nom;
    }
    
    public int getage(){
        return age;
    }
    
    
    public void setage(int age){
        this.age = age;
    }
    
    public void setId(Long id){
        this.id = id;
    }
    
    public Long getId(){
        return this.id;
    }
    
    public static Finder<Long,Personne> find = new Finder<Long,Personne>(Personne.class);
    
}